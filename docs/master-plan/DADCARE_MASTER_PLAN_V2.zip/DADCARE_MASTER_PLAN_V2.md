# DADCARE MASTER PLAN — VERSION 2

## 1. Project definition

DADCARE is a serious, production-grade, multi-tenant business-management and online-advertising platform.

It is open to users from any country. It must not be described as an East African-only or African-only product.

Initial users may come from African countries, but the architecture must support future global expansion.

DADCARE is not a cryptocurrency exchange, forex platform, bank, investment platform, payment custodian, or escrow service.

The platform manages business operations and allows eligible businesses to advertise products in a marketplace.

## 2. Technology policy

The project’s primary programming language is Python.

Required backend stack:

- Python
- Django
- Django REST Framework where APIs are necessary
- PostgreSQL
- Django Templates

Do not introduce Node.js, Express, React, Vue, Angular, Next.js, Nuxt, Firebase as the primary backend, or a second backend language without written owner approval.

Frontend rules:

- Prefer server-rendered Django Templates.
- Use standard HTML and CSS.
- Minimize custom JavaScript.
- Do not put business logic in JavaScript.
- Authentication, subscriptions, permissions, currency, stock, marketplace eligibility, and validation must be controlled by Python.
- Browser-side code must never be treated as the authority.
- Never place Node/Express backend code inside static frontend files.
- Existing JavaScript may be retained temporarily while the system is migrated safely.
- Do not rewrite the entire working project at once.

## 3. Owner approval rule

The project owner’s master plan is the source of truth.

Every AI assistant or developer must follow these rules:

1. Do not redesign the architecture independently.
2. Do not add features outside the current phase.
3. Do not remove existing product logic.
4. Do not create demo pages or fake data.
5. Do not change technologies without permission.
6. Do not rename APIs, models, or business concepts without explaining why.
7. Do not modify unrelated files while fixing one bug.
8. Do not introduce a new subscription policy.
9. Do not change restricted and unrestricted features.
10. Do not change marketplace access rules.
11. Do not change supported languages or currencies.
12. Do not make major database migrations without approval.

Before any architectural change, return:

```text
PROPOSED CHANGE:
WHY IT IS NECESSARY:
FILES AFFECTED:
DATABASE IMPACT:
SECURITY IMPACT:
ALTERNATIVES:
ROLLBACK PLAN:
OWNER APPROVAL REQUIRED: YES
```

No implementation may proceed until the owner approves it.

## 4. Languages

Initial supported languages:

1. English
2. Kiswahili
3. Bemba

Default language: English

First-visit flow:

1. Read a saved language preference if one exists.
2. Otherwise display English by default.
3. Provide a visible language selector.
4. Allow switching to Kiswahili or Bemba.
5. Save the selected language to the user profile.
6. A guest preference may also be saved locally.
7. After login, the server-side user preference is the source of truth.

Language codes:

```text
en = English
sw = Kiswahili
bem = Bemba
```

Use Django internationalization with `gettext_lazy` and template `{% trans %}` tags.

## 5. Country and currency logic

Every business must have a country.

Suggested fields:

```python
country_code
currency_code
timezone
language
```

Use ISO 3166-1 alpha-2 for countries, ISO 4217 for currencies, and IANA timezone names.

Examples:

```text
Zambia       -> ZM -> ZMW
Tanzania     -> TZ -> TZS
Kenya        -> KE -> KES
Uganda       -> UG -> UGX
Rwanda       -> RW -> RWF
South Africa -> ZA -> ZAR
Nigeria      -> NG -> NGN
Ghana        -> GH -> GHS
Botswana     -> BW -> BWP
Malawi       -> MW -> MWK
Mozambique   -> MZ -> MZN
```

Currency behavior:

1. During business creation, the user selects a country.
2. The system suggests the default currency for that country.
3. The business owner confirms it.
4. Currency is saved on the business or shop settings.
5. Every financial record also stores the currency used.
6. Historical records must not change when the business later changes its default currency.
7. Do not assume TZS globally.
8. Do not derive currency only from browser location.
9. Do not use IP address as final authority.
10. Currency formatting must follow the business currency.

All African countries must be represented in one validated country/currency dataset, not scattered through views.

## 6. Product scope

Initial modules:

- authentication
- businesses and tenants
- staff and permissions
- products
- categories
- stock
- sales
- customers
- suppliers
- purchase orders
- reports
- marketplace advertising
- subscription management

Do not initially implement investments, forex trading, crypto trading, lending, interest, customer deposits, custodial wallets, user-to-user money transfers, marketplace escrow, or automatic conversion of customer funds.

## 7. Subscription payment through cryptocurrency

All DADCARE subscription plans may be paid using supported cryptocurrencies.

DADCARE must only collect its own subscription fees. It must not hold or transfer money on behalf of business customers.

The platform displays an approved payment destination containing:

- asset
- network
- public address
- required amount
- payment reference
- expiry time
- required confirmations

Example assets may include USDT, USDC, and BTC.

Networks must be explicit. For example, USDT on TRON, Ethereum, and BNB Smart Chain are separate payment methods.

Do not hardcode a personal Binance or OKX deposit address directly into source code.

Preferred production approach:

- use platform-controlled, network-specific receiving addresses;
- store them as secure environment configuration or encrypted administrative records;
- allow administrators to activate or replace an address without redeploying code.

Suggested payment-request fields:

```python
class SubscriptionPaymentRequest(models.Model):
    id
    business
    subscription_plan
    fiat_reference_currency
    fiat_reference_amount
    crypto_asset
    crypto_network
    crypto_amount
    destination_address
    destination_memo
    payment_reference
    transaction_hash
    status
    expires_at
    confirmations_required
    confirmations_received
    verified_at
    created_at
    updated_at
```

Statuses:

```text
pending
submitted
confirming
confirmed
under_review
expired
rejected
underpaid
overpaid
wrong_network
```

Activation requires server-side verification, automatic through a trusted blockchain-data provider or manual approval by a platform administrator during the first production phase.

The backend verifies the transaction exists, destination, network, asset, amount, confirmations, uniqueness, and request expiry.

Security rules:

- Never store private keys in the repository.
- Never expose private keys through frontend code.
- Never activate payment using frontend-only data.
- Record every manual approval in an audit log.
- Use decimal types, never floating-point values, for monetary amounts.
- Keep subscription pricing and exchange-rate snapshots auditable.
- The crypto-payment module must be disableable without breaking the ERP.

## 8. Subscription states

```text
trial
active
grace_period
expired
suspended
cancelled
```

The backend must calculate access from subscription state and dates. The server is the only authority.

## 9. Feature-access policy

### Active subscription allows

- normal sales
- product creation and editing
- stock viewing
- stock adjustment
- restocking
- supplier management
- customer management
- staff hiring and invitations
- permission management
- reports
- purchase orders
- marketplace uploads
- marketplace listing management
- advanced business settings

### Expired subscription blocks

- uploading products to marketplace
- publishing or editing marketplace listings
- viewing detailed stock information
- stock adjustment
- restocking
- creating purchase orders
- inviting or hiring staff
- editing staff permissions
- viewing reports and analytics
- exporting reports
- premium administrative features

### Expired subscription still allows

- login and logout
- viewing business identity
- selling existing products
- creating ordinary sales
- viewing sales required for daily work
- basic customer selection during a sale
- viewing subscription status
- viewing payment instructions
- submitting payment proof
- renewing subscription
- essential account settings
- support access

Expired subscriptions must not delete business data.

The point-of-sale backend may internally verify and reduce stock, but detailed stock screens and inventory reports remain restricted.

## 10. Central feature-gating system

Do not scatter subscription checks across random views.

Example:

```python
class SubscriptionFeature:
    MARKETPLACE_PUBLISH = "marketplace_publish"
    STOCK_VIEW = "stock_view"
    STOCK_ADJUST = "stock_adjust"
    RESTOCK = "restock"
    STAFF_MANAGE = "staff_manage"
    REPORTS_VIEW = "reports_view"
    SALE_CREATE = "sale_create"
```

Create a centralized policy:

```python
def business_can_use(business, feature):
    ...
```

Blocked response:

```json
{
  "success": false,
  "error": "An active subscription is required for this feature.",
  "code": "SUBSCRIPTION_REQUIRED",
  "feature": "stock_adjust"
}
```

Use HTTP 403, not HTTP 500.

## 11. Marketplace logic

The marketplace is for businesses to advertise and sell products online. It is not automatically a financial intermediary.

A business may publish or update marketplace listings only when:

- subscription is active;
- business is not suspended;
- user has marketplace permission;
- listing passes validation;
- underlying product is active.

Recommended expiry policy:

- pause public listings immediately;
- set listing status to `subscription_paused`;
- do not delete listings;
- restore after renewal according to owner-approved rules.

Marketplace listings must be separate from internal Product records.

Never expose cost price, private supplier details, internal stock movements, staff information, private reports, or internal notes.

## 12. Python clean-code standards

Use clear Django apps, services for complex writes, selectors for reads, serializers/forms for validation, transactions, permissions, type hints where useful, small functions, meaningful names, tests, and structured logging.

Suggested layout:

```text
apps/
  accounts/
  businesses/
  subscriptions/
  products/
  inventory/
  sales/
  customers/
  suppliers/
  staff/
  reports/
  marketplace/
  payments/
```

Suggested pattern:

```text
models.py       -> persistence structure
services.py     -> write/business operations
selectors.py    -> optimized reads
permissions.py  -> authorization
validators.py   -> reusable validation
tasks.py        -> background work
tests/          -> tests
```

Example:

```python
@transaction.atomic
def create_product(*, business, user, validated_data):
    ...
```

Do not create god files.

## 13. Immediate development phases

### Phase 1 — Stabilize existing production

- Fix product-create HTTP 500.
- Verify all migrations.
- Verify tenant isolation.
- Verify login and business selection.
- Remove accidental Node/Express code.
- Stop browser routing loops.
- Return validation errors instead of 500.
- Add tests for product creation.
- Add country and currency fields safely.
- Default UI language to English.
- Add Kiswahili and Bemba translation structure.

### Phase 2 — Subscription foundation

- Add plans.
- Add subscription states.
- Add subscription dates.
- Add centralized feature-access policies.
- Apply active/expired rules.
- Add subscription-status UI.
- Do not add crypto activation before subscription permissions are tested.

### Phase 3 — Cryptocurrency subscription payments

- Add supported assets and networks.
- Add payment requests.
- Add transaction-hash submission.
- Add manual admin verification.
- Add audit logging.
- Prevent duplicate transaction use.
- Add confirmations and expiry logic.
- Test wrong-network and underpayment cases.

### Phase 4 — Stable inventory and sales

- Products.
- Categories.
- Stock movements.
- Sales.
- Sale items.
- Customers.
- Suppliers.
- Atomic stock deductions.
- Currency saved per transaction.
- Expired subscriptions may sell but cannot use restricted inventory tools.

### Phase 5 — Marketplace advertising

- Marketplace listings separate from products.
- Subscription checks.
- Public marketplace.
- Listing moderation.
- Automatic pause on subscription expiry.
- No customer-fund custody.

### Phase 6 — Staff and permissions

- Invite staff.
- Assign roles.
- Restrict hiring and permissions to active subscriptions.
- Backend authorization.
- Audit logs.

### Phase 7 — Reports

- Sales reports.
- Profit reports.
- Stock reports.
- Country/currency-aware formatting.
- Active-subscription requirement.
- Safe exports.

### Phase 8 — Offline support

- Cache only safe static resources.
- Queue permitted sales operations.
- Use idempotency keys.
- Do not cache private APIs indefinitely.
- Do not allow offline subscription activation.
- Do not allow offline staff permissions or marketplace publication.

## 14. Immediate instruction to the AI developer

Before generating code:

1. Read this entire master plan.
2. Inspect the current repository.
3. Identify differences between current code and the plan.
4. Do not rewrite the project.
5. Do not modify files yet.
6. Produce an audit.

Required response:

```text
CURRENT ARCHITECTURE:
...

CONFLICTS WITH MASTER PLAN:
...

CURRENT DATABASE MODELS:
...

CURRENT AUTHENTICATION:
...

CURRENT TENANT STRATEGY:
...

CURRENT SUBSCRIPTION SUPPORT:
...

CURRENT COUNTRY/CURRENCY SUPPORT:
...

CURRENT MARKETPLACE SUPPORT:
...

CURRENT PRODUCT-CREATE 500 ROOT CAUSE:
...

PROPOSED PHASE-1 CHANGES:
...

FILES THAT WOULD CHANGE:
...

MIGRATIONS REQUIRED:
...

RISKS:
...

ROLLBACK PLAN:
...

OWNER APPROVAL REQUIRED BEFORE CODING: YES
```

The AI must wait for owner approval before writing or replacing files.
